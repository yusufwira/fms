//Server=ej-azurepg.postgres.database.azure.com;Database=postlog;Port=5432;User Id=ejuser@ej-azurepg;Ssl Mode=Require;Password=i988KH234*(kqpj;

import pkg from 'pg';
const { Client } = pkg;

function insert(d) {
    var client = new Client({
        user: 'ejuser@ej-azurepg',
        host: 'ej-azurepg.postgres.database.azure.com',
        database: 'nodetest',
        password: '__',
        port: 5432,
        ssl: true
    });
    client.connect();
    var jsonString = JSON.stringify('{ "customer": "' + d + '", "items": {"product": "Beer","qty": 6}}');
    var sql = `INSERT INTO avl (datetime, avl) VALUES (NOW(), '${jsonString}')`;

    client.query(sql, (err, res) => {
        if (err) {
            console.error(err);
        }else{
            console.log('insert success');
        }

        client.end();
        return;

    });
}

insert('a');
insert('b');