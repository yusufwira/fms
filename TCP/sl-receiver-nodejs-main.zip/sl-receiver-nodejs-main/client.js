import { Socket } from 'net';

var client = new Socket();
client.connect(8585, '127.0.0.1', function() {
	console.log('Connected');
	var r = client.write('r');
	console.log('send ' + r);
});

client.on('data', function(data) {
	console.log('Received: ' + data[0]);
	console.log('Length: ' + data.byteLength);
	//client.destroy(); // kill client after server's response
});

client.on('close', function() {
	console.log('Connection closed');
});