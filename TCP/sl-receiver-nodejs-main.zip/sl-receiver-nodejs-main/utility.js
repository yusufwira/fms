
export  default function bin2String(array) {
    return String.fromCharCode.apply(String, array);
}