import { createServer } from 'net';
import binutils from 'binutils64';
import teltonikaParser from 'teltonika-parser';
import moment from 'moment';
import pg from 'pg'

// const { Client } = pkg;
const { Pool } = pg;
const pool = new Pool({
	user: 'postgres',
	host: 'localhost',
	database: 'fms-node1',
	password: 'pg8208)^Rw',
	port: 5432,
	max: 100,
	idleTimeoutMillis: 30000,
	connectionTimeoutMillis: 2000,
});

var CLIENTSOCKETKEYLIST = []; // contoh: ['202.169.1.2_84913', '202.3.5.5_13423'] --> IP_PORT
var CLIENTLIST = [];
/*
	contoh: [
		'202.169.1.2_84913': { object1 },
		'202.3.5.5_13423': { object2 },
	]
*/

var server = createServer(function (socket) { });

var printClients = function (socket) {
	CLIENTSOCKETKEYLIST.forEach((c) => {
		var cl = CLIENTLIST[c];
		socket.write(cl.imei + ' | ' + cl.timestamp + '\r\n');
	});
}

var removeClient = function (socket) {
	var key = socket.remoteAddress + ":" + socket.remotePort;
	CLIENTLIST[key] = null;
	var idx = CLIENTSOCKETKEYLIST.indexOf(key);
	CLIENTSOCKETKEYLIST.splice(idx, 1);
}

var removeAndCloseSocketConnection = function (socket) {
	removeClient(socket);
	printClients(socket);
	socket.destroy();
}

var addClientToList = function (socket) {
	var key = socket.remoteAddress + "_" + socket.remotePort;

	CLIENTLIST[key] = {
		socket,
		imei: '',
		id: CLIENTSOCKETKEYLIST.length,
		timestamp: new Date(),
		buffer: []
	};
	CLIENTSOCKETKEYLIST.push(key);
}

var updateIMEI = function (socket, byteArray) {
	var imei = getIMEI(byteArray);
	var key = socket.remoteAddress + "_" + socket.remotePort;
	CLIENTLIST[key].imei = new Buffer.from(imei).toString();
	return CLIENTLIST[key].imei;
}

var clearIdle = function(){
	//
}

var updateClientInfo = function(socket){
	var key = socket.remoteAddress + "_" + socket.remotePort;
	CLIENTLIST[key].last_data = new Date();
}

var updateBufferPacket = function (socket, byteArray) {
	var key = socket.remoteAddress + "_" + socket.remotePort;
	CLIENTLIST[key].buffer = CLIENTLIST[key].buffer.concat(byteArray);
	return CLIENTLIST[key].buffer;
}

var flushBufferPacket = function(socket){
	var key = socket.remoteAddress + "_" + socket.remotePort;
	CLIENTLIST[key].buffer =[];
	return CLIENTLIST[key].buffer;
}

var isIMEI = function (byteArray) {
	return getIMEI(byteArray);
}

var getIMEI = function (byteArray) {
	if (byteArray.length > 2
		&& byteArray[0] == 0x00) {

		var imeiLength = byteArray[1];
		var imei = byteArray.slice(2);

		if (imei.length == imeiLength) {
			return imei;
		} else {
			return false;
		}
	}
	return false;
}

var replyIMEIReceived = function (socket) {
	var message = Buffer.from([1]);
	var d = socket.write(message);
	console.log(getSocketID(socket) + " " + 'reply flush: ' + d);
}

var isAVLPacket = function (byteArray) {
	//let parser = new teltonikaParser(byteArray);
	return byteArray.length > 4 &&
		byteArray[0] == 0 &&
		byteArray[1] == 0 &&
		byteArray[2] == 0 &&
		byteArray[3] == 0;
}

var replyAVLPacketReceived = function (socket, byteArray) {

	let parser = new teltonikaParser(byteArray);
	let avl = parser.getAvl();
	let numberOfData = avl.number_of_data;

	console.log("number of data ", numberOfData);

	let writer = new binutils.BinaryWriter();
	writer.WriteInt32(numberOfData);
	let response = writer.ByteBuffer;

	console.log("response ", response);
	socket.write(response);
	console.log(getSocketID(socket) + " " + 'reply number of data: ' + numberOfData);
}

var byteArrayToHexString = function (byteArray) {
	return Array.from(byteArray, function (byte) {
		return ('0' + (byte & 0xFF).toString(16)).slice(-2);
	}).join('')
}

var saveAVLPacket = function (socket, byteArray) {
	//write to database
	var key = socket.remoteAddress + "_" + socket.remotePort;
	var socketClient = CLIENTLIST[key];
	let imei = socketClient.imei;
	let imeiTime = new moment(socketClient.timestamp).format('YYYY-MM-DD HH:mm:ss');
	let parser = new teltonikaParser(byteArray);
	let avl = parser.getAvl();
	console.log(getSocketID(socket) + " Number of Data: " + avl.number_of_data);


	//var hexString= byteArrayToHexString(byteArray); //simpan ke kolom hex
	var startTime = new moment();
	var connectTime = new moment().format('YYYY-MM-DD HH:mm:ss');
	var records = avl.records;
	// var sql = `INSERT INTO raw.raw_linux (imei_time, connect_time, imei, servertime, devicetime, satellite, latitude, longitude, eventioid, ioall, altitude, angle) `;
	var sql = `INSERT INTO raw.raw_linux (imei_time, imei, servertime, devicetime, satellite, latitude, longitude, eventioid, ioall, altitude, angle) `;
	for (var i = 0; i < records.length; i++) {
		if (i == 0) {
			sql += `VALUES `;
		}
		else {
			sql += `,`;
		}
		var devicetime = new Date(records[i].timestamp).toISOString();
		var servertime = new Date(Date.now()).toISOString();
		var satellite = records[i].gps.satellites;
		var latitude = records[i].gps.latitude;
		var longitude = records[i].gps.longitude;
		var altitude = records[i].gps.altitude;
		var angle = records[i].gps.angle;
		var eventioid = records[i].event_id;
		var ioElements = records[i].ioElements;

		var ioall = "";
		for (var j = 0; j < ioElements.length; j++) {
			if (j > 0) {
				ioall += "|";
			}
			ioall += ioElements[j].id + "," + ioElements[j].value;
		}

		//sql += `('${imeiTime}','${connectTime}', '${imei}', NOW(), '${devicetime}', ${satellite}, ${latitude}, ${longitude}, ${eventioid}, '${ioall}', ${altitude}, ${angle})`;
		sql += `('${imeiTime}', '${imei}', '${servertime}', '${devicetime}', ${satellite}, ${latitude}, ${longitude}, ${eventioid}, '${ioall}', ${altitude}, ${angle})`;
	}

	pool.query(sql, (err, res) => {
		if (err) {
			console.error(err);
		} else {
			console.log('insert success');
		}

		var endTime = new moment();
		var span = moment.duration(endTime.diff(startTime));
		console.log("insert time (ms)", span.asMilliseconds());
	});
}

var getSocketID = function (socket, pad) {
	var key = socket.remoteAddress + "_" + socket.remotePort;
	return key.padStart(22, ' ');
};

server.listen(8585);

server.on("connection", (socket) => {
	console.log(getSocketID(socket) + " " + "client connected");
	addClientToList(socket);

	socket.on("data", (data) => {
		var byteLength = data.byteLength;
		console.log(getSocketID(socket) + " " + "BYTE RECEIVED: " + byteLength);
		updateClientInfo(socket);
		var byteArray = [];
		for (var i = 0; i < byteLength; i++) {
			byteArray.push(data[i]);
		}

		///	bagian ini untuk monitoring
		///	caranya: pakai telnet IP PORT
		///	terus salah satu karakter ini: * - r
		///	* print connected client
		///	- close connection
		/// r simulate reply IMEI
		/// a simulate reply avl --> error

		if (byteLength == 1) {
			if (byteArray[0] == 42) {// *				
				printClients(socket);
			}

			if (byteArray[0] == 45) {// -				
				console.log(getSocketID(socket) + " Close command detected");
				removeAndCloseSocketConnection(socket);
			}

			if (byteArray[0] == 114) { //r
				replyIMEIReceived(socket);
			}

			if (byteArray[0] == 97) { //a
				replyAVLPacketReceived(socket, byteArray);
			}
		} else if (byteLength > 0) {

			//printByteArray(socket, byteArray);
			if (isIMEI(byteArray)) {
				var i = updateIMEI(socket, byteArray);
				console.log(getSocketID(socket) + " " + "IMEI DETECTED: " + i);
				replyIMEIReceived(socket);
			} else {
				var totalBuffer = updateBufferPacket(socket, byteArray);
				if (isAVLPacket(totalBuffer)) {
					console.log(getSocketID(socket) + " " + "AVL DETECTED: " + totalBuffer.length + " BYTES");					
					replyAVLPacketReceived(socket, totalBuffer);
					saveAVLPacket(socket, totalBuffer);
					//removeAndCloseSocketConnection(socket);
					flushBufferPacket(socket);
				}
			}
		}
	});

	socket.on("end", () => {
		removeClient(socket);
		var key = socket.remoteAddress + "_" + socket.remotePort;
		console.log(getSocketID(socket) + " " + "bye! " + key);
	});

	socket.on("error", () => {
		console.log("error");
	});
});

server.on("error", () => {
	console.log("server error");
});

server.on("listening", () => {
	console.log("SERVER LISTENING ", server.address());
});
